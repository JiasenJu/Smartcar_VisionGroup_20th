#ifndef _PID_H_
#define _PID_H_

#include "zf_common_headfile.h"



struct pid_parameter
{
	float kp;
	float ki;
	float kd;
	float expect;
	float error_now;
	float error_last;
	float error_last_last;
	float error_integral;
	int32 output; 
};


void Incremental_PID(struct pid_parameter *pid,int16 speed_now);
void Direction_PD(struct pid_parameter *pid, float mid_error);

void Positional_Vel_PD(struct pid_parameter *pid);
void Position_PID(struct pid_parameter *pid,float angle);
void Position_XY_PID(struct pid_parameter *pid);


#endif /* _PID_H_ */
