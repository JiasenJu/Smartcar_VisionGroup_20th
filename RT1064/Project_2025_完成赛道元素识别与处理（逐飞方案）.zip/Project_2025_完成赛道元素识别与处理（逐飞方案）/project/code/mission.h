#ifndef __MISSION_H
#define __MISSION_H
#include "zf_common_headfile.h"


// ����ͼƬ��������
#define expect_pic_y 135      
#define expect_pic_x 105

extern uint8 adject_finish_flag;
extern uint8 push_box_state;


void Position_Adjest(void);

void Push_Box(uint8 mode);

#endif

