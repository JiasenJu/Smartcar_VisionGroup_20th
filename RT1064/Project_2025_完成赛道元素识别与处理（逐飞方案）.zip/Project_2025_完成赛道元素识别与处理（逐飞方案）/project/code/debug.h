#ifndef __DEBUG_H
#define __DEBUG_H

#include "zf_common_headfile.h"


void Wireless_Debug(void);

void Finall_Display(void);
void Item_Display(uint16 x, uint16 y, uint8 item);

#endif

