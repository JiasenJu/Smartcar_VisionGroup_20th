#include "zf_common_headfile.h"
#include "motor.h"


/*  �����ֱ�ţ� 

0(LH)       1(RH)


      2(MB)
      
�����н�����
  y ^    
    |
    |
    |
    |
    ����������>x
�涨���Գ�ͷǰ������Ϊy������ˮƽ����Ϊx������˳ʱ��Ϊw������
*/
uint8 move_mode=1;      // ����ģʽѡ�� 1�����ֱַ�����ٶ�  2���˶��ֽ�

uint8 stop_flag=0;      // ͣ����־λ 0������ 1��ͣ��
uint8 go_flag=1;        // ������־λ 0��ͣ�� 1������
uint8 line_flag = 1;    // Ѳ��ģʽ��־λ 0��ֹͣѲ�� 1��Ѳ��ģʽ

uint8 turn_flag=0;      // �̶��Ƕ�ת���־λ

struct pid_parameter motor_pid0, motor_pid1, motor_pid2;    // �ٶȻ�
struct pid_parameter dir_pid;                   // ѭ��λ�û�
struct pid_parameter angle_pid;                 // �ǶȻ������ٶȻ�
struct pid_parameter pic_pid_x,pic_pid_y;       // ͼƬ�����������

int16 motor_speed_base;     // ѭ��ģʽ���������ٶ�
int16 vx=0,vy=0,vw=0;       // �ٶȷֽ�

int16 real_Vx=0,real_Vy=0;
int16 inter_VX=0,inter_VY=0;
int32 distance_x=0,distance_y=0;


void MotorPID_Parameter_Init(void)
{
    // ��ǰ
	motor_pid0.kp                =5.5;    
	motor_pid0.ki                =0.9;  
	motor_pid0.kd                =0;
	motor_pid0.expect            =0;
	motor_pid0.error_now         =0;
	motor_pid0.error_last        =0;
	motor_pid0.error_last_last   =0;
	motor_pid0.output            =0; 
      
    // ��ǰ
	motor_pid1.kp                =5.5;   
	motor_pid1.ki                =0.9; 
	motor_pid1.kd                =0;
	motor_pid1.expect      	     =0;
	motor_pid1.error_now         =0;
	motor_pid1.error_last        =0;
	motor_pid1.error_last_last   =0;
	motor_pid1.output            =0;
     
    // �к�
	motor_pid2.kp                =5.5;  
	motor_pid2.ki                =0.9;
	motor_pid2.kd                =0;
	motor_pid2.expect    	     =0;
	motor_pid2.error_now         =0;
	motor_pid2.error_last        =0;
	motor_pid2.error_last_last   =0;
	motor_pid2.output            =0;	
    
    // ѭ��λ�û�
	dir_pid.kp                  =1.8;  
	dir_pid.ki                  =0;
	dir_pid.kd                  =35;
	dir_pid.expect    	        =0;
	dir_pid.error_now           =0;
	dir_pid.error_last          =0;
	dir_pid.error_last_last     =0;
	dir_pid.output              =0;
    
    // �Ƕȱջ�PD
    angle_pid.kp                  =48;
    angle_pid.ki                  =0;
    angle_pid.kd                  =28;
    angle_pid.expect    	   	  =0;
    angle_pid.error_now           =0;
    angle_pid.error_last          =0;
    angle_pid.error_last_last     =0;
    angle_pid.output              =0;
    
    
    // ͼƬ����������� x��
    pic_pid_x.kp                  =-4.5;
    pic_pid_x.ki                  =-0.01;
    pic_pid_x.kd                  =-12;
    pic_pid_x.expect    	   	  =0;
    pic_pid_x.error_now           =0;
    pic_pid_x.error_last          =0;
    pic_pid_x.error_last_last     =0;
    pic_pid_x.output              =0;
    
    // ͼƬ����������� y��
    pic_pid_y.kp                  =8;
    pic_pid_y.ki                  =0;
    pic_pid_y.kd                  =2;
    pic_pid_y.expect    	   	  =0;
    pic_pid_y.error_now           =0;
    pic_pid_y.error_last          =0;
    pic_pid_y.error_last_last     =0;
    pic_pid_y.output              =0;
}

void Motor_Control(void)
{
    if(text_pic_flag==1)    move_mode=2;
    else                    move_mode=1;
    if(move_mode == 1)
    {
        motor_speed_base = 100; 
        
        motor_pid0.expect = motor_speed_base;
        motor_pid1.expect = motor_speed_base; 
        motor_pid2.expect = 0;
        
        if(line_flag)   // ѭ��ģʽ
        {
            Direction_PD(&dir_pid, (float)mid_offset);
            motor_pid0.expect = motor_speed_base+dir_pid.output;
            motor_pid1.expect = motor_speed_base-dir_pid.output;
        }        
        
        // ����ʽ�ٶȻ�PI
        Incremental_PID(&motor_pid0,encoder_data[0]);
        Incremental_PID(&motor_pid1,encoder_data[1]);
        Incremental_PID(&motor_pid2,encoder_data[2]);	
    }
    else if(move_mode == 2)
    {
        Direction_Control();
        
        // ����ʽ�ٶȻ�PI
        Incremental_PID(&motor_pid0,encoder_data[0]);
        Incremental_PID(&motor_pid1,encoder_data[1]);
        Incremental_PID(&motor_pid2,encoder_data[2]);        
    }


    encoder_integral();
    
    if(motor_pid0.output>=0) {gpio_set_level(LH_EN_PIN,0);pwm_set_duty(LH_PWM_PIN,motor_pid0.output);}// ��ǰ
	if(motor_pid0.output<0)  {gpio_set_level(LH_EN_PIN,1);pwm_set_duty(LH_PWM_PIN,-motor_pid0.output);}
	
	if(motor_pid1.output>=0) {gpio_set_level(RH_EN_PIN,1);pwm_set_duty(RH_PWM_PIN,motor_pid1.output);}// ��ǰ
	if(motor_pid1.output<0)  {gpio_set_level(RH_EN_PIN,0);pwm_set_duty(RH_PWM_PIN,-motor_pid1.output);}

	if(motor_pid2.output>=0) {gpio_set_level(MB_EN_PIN,1);pwm_set_duty(MB_PWM_PIN,motor_pid2.output);}// �к�
	if(motor_pid2.output<0)  {gpio_set_level(MB_EN_PIN,0);pwm_set_duty(MB_PWM_PIN,-motor_pid2.output);}
}

// ����������
void encoder_integral(void)
{
	real_Vx=(encoder_data[0]-encoder_data[1]+encoder_data[2])/3;
	real_Vy=(encoder_data[0]+encoder_data[1]+encoder_data[2])/3;
	
	inter_VX=(int16)((float)real_Vx*cos(Yaw/180*PI)+(float)real_Vy*sin(Yaw/180*PI));
	inter_VY=(int16)((float)real_Vy*cos(Yaw/180*PI)-(float)real_Vx*sin(Yaw/180*PI));
	
	distance_x+=inter_VX;
	distance_y+=inter_VY;
}


// �ٶȷֽ⣬���Vx Vy w
void Direction_Control(void)
{
    motor_pid0.expect = 0.333*vx + 0.577*vy + 0.333*vw;
    motor_pid1.expect = -0.333*vx + 0.577*vy - 0.333*vw;
    motor_pid2.expect = 0.667*vx + 0.333*vw;

//	if(motor_pid0.expect>200||motor_pid0.expect<-200) stop_flag=1;
//	if(motor_pid1.expect>200||motor_pid1.expect<-200) stop_flag=1;
//	if(motor_pid2.expect>200||motor_pid2.expect<-200) stop_flag=1;
}


/****************************************************************
 *  @brief    �����ǽǶȱջ������ڿ������֣����Ƕ���ת���̶�������ʻ��
 *  @param    �����ǵ�ǰyaw��
 *  @return   void
 *  Sample usage
*****************************************************************/
void Angle_Control(float angle)
{
    Position_PID(&angle_pid,angle+yaw_last);     //�ǶȻ�
    vw=angle_pid.output;
}


// ����XY��������ٶ����й̶�ʱ��
void Motor_Move(int16 x_speed, int16 y_speed, uint16 time)
{
    vx = x_speed;
    vy = y_speed;
    system_delay_ms(time);
    
    vx = 0;
    vy = 0;
}

void Motor_Init(void)
{
    pwm_init(LH_PWM_PIN, 17000, 0); // ��ʼ�� PWMͨ�� Ƶ��17KHz ��ʼռ�ձ� 0%
    pwm_init(RH_PWM_PIN, 17000, 0);    
    pwm_init(MB_PWM_PIN, 17000, 0);     
    
    gpio_init(LH_EN_PIN, GPO, 1, GPO_PUSH_PULL); // ʹ�����ų�ʼ��
    gpio_init(RH_EN_PIN, GPO, 1, GPO_PUSH_PULL);
    gpio_init(MB_EN_PIN, GPO, 1, GPO_PUSH_PULL);
}

// ����ʹ��
void Motor_SpeedText(int16 speed_lh, int16 speed_rh, int16 speed_mb)
{
    
    if(speed_lh>=0) {gpio_set_level(LH_EN_PIN,1);pwm_set_duty(LH_PWM_PIN, speed_lh);}// ��ǰ
	if(speed_lh<0)  {gpio_set_level(LH_EN_PIN,0);pwm_set_duty(LH_PWM_PIN,-speed_lh);}
	
	if(speed_rh>=0) {gpio_set_level(RH_EN_PIN,1);pwm_set_duty(RH_PWM_PIN, speed_rh);}// ��ǰ
	if(speed_rh<0)  {gpio_set_level(RH_EN_PIN,0);pwm_set_duty(RH_PWM_PIN,-speed_rh);}

	if(speed_mb>=0) {gpio_set_level(MB_EN_PIN,1);pwm_set_duty(MB_PWM_PIN, speed_mb);}// �к�
	if(speed_mb<0)  {gpio_set_level(MB_EN_PIN,0);pwm_set_duty(MB_PWM_PIN,-speed_mb);}

}