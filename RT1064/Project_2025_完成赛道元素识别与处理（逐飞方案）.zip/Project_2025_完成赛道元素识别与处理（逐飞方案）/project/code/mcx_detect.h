#ifndef _MCX_DETECT_H_
#define _MCX_DETECT_H_

#include "zf_common_headfile.h"

void MCX_Uart_Init(void);

void Pic_Text(void);


#endif 
