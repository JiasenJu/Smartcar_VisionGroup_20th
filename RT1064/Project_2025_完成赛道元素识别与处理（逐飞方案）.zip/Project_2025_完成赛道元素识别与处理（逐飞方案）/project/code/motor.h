#ifndef __MOTOR_H
#define __MOTOR_H

#include "zf_common_headfile.h"



/* �����ֵ�����Ŷ��� */
#define LH_PWM_PIN     (PWM1_MODULE3_CHA_D0)     // PWM ����        // ��ǰ
#define LH_EN_PIN      C12                       // ʹ������     
                                               
#define RH_PWM_PIN     (PWM1_MODULE3_CHB_D1)     // PWM ����        // ���
#define RH_EN_PIN      C9                        // ʹ������        
                                               
#define MB_PWM_PIN     (PWM2_MODULE3_CHB_D3)     // PWM ����        // ��ǰ
#define MB_EN_PIN      C7                        // ʹ������        
 
extern uint8 move_mode;
extern uint8 stop_flag;
extern uint8 go_flag;  
extern uint8 line_flag;
extern uint8 turn_flag;


extern int16 vx,vy,vw;  
extern int32 distance_x,distance_y;


extern struct pid_parameter motor_pid0, motor_pid1, motor_pid2;
extern struct pid_parameter dir_pid;
extern struct pid_parameter angle_pid; 
extern struct pid_parameter pic_pid_x,pic_pid_y;


extern int16 motor_speed_base;


void MotorPID_Parameter_Init(void);
void Motor_Control(void);
void Direction_Control(void);

void Angle_Control(float angle);
void Motor_Move(int16 x_speed, int16 y_speed, uint16 time);

void encoder_integral(void);

void Motor_Init(void);
void Motor_SpeedText(int16 speed_lh, int16 speed_rh, int16 speed_mb);


#endif

