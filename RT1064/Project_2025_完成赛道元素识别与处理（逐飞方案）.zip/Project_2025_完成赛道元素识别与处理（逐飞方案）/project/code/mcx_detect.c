#include "mcx_detect.h"


// MCX识别图片期望坐标
#define PIC_EXP_X   150
#define PIC_EXP_Y   100

// 确认检测到图片Y轴的坐标
#define PIC_TEXT_EXP_Y  50

/*  MCX返回图片坐标示意： 
   0 —————>x  240
240 |
    |
    |
0   |
   y 
*/

// 目标检测openart数据定义
uint8 uart_get_data_2[64];          // openart_mini 1号摄像头UART1串口接收数据缓冲区
uint8 fifo_get_data_2[64];          // fifo 输出读出缓冲区
uint8 get_data_2 = 0;               // 接收数据变量
uint32 fifo_data_count_2 = 0;       // fifo数据个数
fifo_struct uart_data_fifo_2;       // FIFO结构体
uint8* uart_data_2=NULL;             // 串口数据转存地址，在此基础上进行运动控制


/**********  目标检测   *************/
uint8 text_uart_flag = 0;           // 串口接收到数据标志位，接收到数据置1
uint8 text_pic_flag = 0;            // 目标检测标志位，检测到图片置1
uint8 pic_rx_flag = 0;          
uint8 pic_adjust_flag = 0;          // 位置调整标志位
uint16 pic_text_x=0,pic_text_y=0;   // 目标检测图片中心点


typedef struct      // MCX目标检测
{
    uint16 res_x1;
    uint16 res_y1;
    uint16 res_x2;
    uint16 res_y2;
}od_result_t;   

volatile od_result_t od_result[10];


uint8 left_pic_taget = 0;       // 图片在赛道左
uint8 right_pic_taget = 0;      // 图片在赛道右
uint16 pic_mid_dist = 0;        // 检测图片距离底边中心距离


// openart串口初始化， UART4, 用作目标检测
void MCX_Uart_Init(void)       
{
    fifo_init(&uart_data_fifo_2, FIFO_DATA_8BIT, uart_get_data_2, 64);      // 初始化 fifo 挂载缓冲区
    uart_init(UART_4, 115200, UART4_TX_C16, UART4_RX_C17);                  // 串口初始化
    uart_rx_interrupt(UART_4, ZF_ENABLE);                                   // 开启 UART_INDEX 的接收中断
    interrupt_set_priority(LPUART4_IRQn, 0);                                // 设置对应 UART_INDEX 的中断优先级为 0
}


// MCX目标监测，串口中断接收返回的图片坐标数据
void uart_MCX_interrupt_handler(void)
{ 
    uint8 get_data_2 = 0;        // 接收数据变量
    uint32 temp_length = 0;
    uint8 od_num = 0;
    
    if(uart_query_byte(UART_4, &get_data_2))
    {
        fifo_write_buffer(&uart_data_fifo_2, &get_data_2, 1);   
    }
    
    if(0xFF == get_data_2)      // 读取第1个数据，用于判断帧头，使用完清除此数据
    {
        text_uart_flag = 1;
        
        temp_length = 1;
        fifo_read_buffer(&uart_data_fifo_2, fifo_get_data_2, &temp_length, FIFO_READ_AND_CLEAN);
        if(0xAA == fifo_get_data_2[0])
        {
            temp_length = 1;    // 读取第1个数据，用于获取目标序号，使用完清除此数据
            fifo_read_buffer(&uart_data_fifo_2, fifo_get_data_2, &temp_length, FIFO_READ_AND_CLEAN);
            od_num = fifo_get_data_2[0];
           
            temp_length = 8;    // 读取8个数据，用于获取目标数据，然后转移到结构体数组中
            fifo_read_buffer(&uart_data_fifo_2, fifo_get_data_2, &temp_length, FIFO_READ_AND_CLEAN);
            memcpy((uint8*)(&od_result[od_num]), fifo_get_data_2, 8);
        
            pic_text_x = (od_result[0].res_x1+od_result[0].res_x2)/2;
            pic_text_y = (od_result[0].res_y1+od_result[0].res_y2)/2;
        }
        fifo_clear(&uart_data_fifo_2);
    }
}



/****************************************************************
 *  @brief    图片检测，在接收到数据后，判断图片的位置
 *  @param    void
 *  @return   void
 *  Sample usage
*****************************************************************/
void Pic_Text(void)
{   
//    int16 error_x = 0;    
//    error_x = PIC_EXP_X - pic_text_x;
    
    
    if((PIC_TEXT_EXP_Y-pic_text_y) <10)
    {
        text_pic_flag = 1;  // 图片达到预定距离
    }
    
    
    
//    if(pic_mid_dist < pic_dis_threshold)
//    {
//        text_pic_flag = 1;  // 图片达到预定距离
//        
//        if(pic_text_x<160)
//        {
//            left_pic_taget = 1;
//            right_pic_taget = 0;
//        }
//        else
//        {
//            left_pic_taget = 0;
//            right_pic_taget = 1;
//        }
//        
//        pic_text_x = 0;
//        pic_text_y = 0;
//    }
    
}

