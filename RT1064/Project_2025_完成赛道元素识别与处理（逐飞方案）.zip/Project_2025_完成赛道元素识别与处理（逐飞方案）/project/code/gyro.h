#ifndef __GYRO_H_
#define __GYRO_H_

#include "zf_common_headfile.h"

#define gyro_originalData_x imu963ra_gyro_x
#define gyro_originalData_y imu963ra_gyro_y
#define gyro_originalData_z imu963ra_gyro_z

#define acc_originalData_x imu963ra_acc_x
#define acc_originalData_y imu963ra_acc_y
#define acc_originalData_z imu963ra_acc_z

typedef struct
{
    int16   x;
    int16   y;
    int16   z;
}imu_data;

typedef struct
{
  imu_data  accdata; //���ٶȼ�
  imu_data  gyro;    //���ٶ�
}imu963_data;

typedef struct
{
  float input_data[3];
  float output_data[3];
}_Butterworth_data;

typedef struct
{
  const float a[3];
  const float b[3];
}_Butterworth_parameter;

extern imu963_data IMU_Offset; //��ƫֵ
extern imu963_data IMU_Finished;  //ԭʼֵ
extern int16 gyro_firstData_z;
extern float gyro_actualData_z;//ʵ������

extern float Yaw;//�����
extern uint8 IMU_Offset_Finished;//��ƫ������ɱ�־λ
extern int32 acc_Vx,acc_Vy;//���ٶȼƻ����ٶ�

extern int16 gyroFilterData_x[10];
extern int16 gyroFilterData_y[10];
extern int16 gyroFilterData_z[10];
extern _Butterworth_data *butterworth_gyro_z;

extern int16 accFilterData_x[10];
extern int16 accFilterData_y[10];

void get_originalData();
void gyro_GetStateData(void);
void gyro_offset();
void gyro_FilterData();
void get_angle();
void integral_acc();
void integral_speed();
int16 SlideAverage_fliter(int16 *SlideData,int16 *object_data,int8 num);



#endif