#ifndef __OPENART_MINI_H_
#define __OPENART_MINI_H_

#include "zf_common_headfile.h"

// Ŀ��ʶ��
extern uint8 uart_get_data_1[64];      
extern uint8 fifo_get_data_1[64];      
extern uint8 get_data_1;           
extern uint32 fifo_data_count_1;   
extern fifo_struct uart_data_fifo_1;
extern uint8* uart_data_1;

// Ŀ����
extern uint8 uart_get_data_2[64];      
extern uint8 fifo_get_data_2[64];      
extern uint8 get_data_2;           
extern uint32 fifo_data_count_2;   
extern fifo_struct uart_data_fifo_2;


extern uint8 left_pic_taget;
extern uint8 right_pic_taget;

extern uint8 text_uart_flag;
extern uint8 text_pic_flag;
extern uint8 pic_rx_flag;  

extern uint8 pic_errow;


extern uint8 pic_adjust_flag;
extern uint16 pic_mid_dist;
extern uint16 pic_x,pic_y;           // Ŀ��ʶ��ͼƬ���ĵ�
extern uint16 pic_text_x,pic_text_y; // Ŀ����ͼƬ���ĵ�
     
extern uint8 pic_classify;    
extern uint8 pic_classify_flag;
     
extern uint8 MsgArt_flag1;
extern uint8 MsgArt_flag2;

extern uint8 num_classify;
extern uint8 num_classify_flag;

extern uint8 char_classify;
extern uint8 char_classify_flag;

void openart_mini_1_Init(void);
void openart_mini_2_Init(void);

void openart_mini_1_CallBack(void);



void SendMsg_art(void);
void uart1_art_task(void);



#endif

