#include "zf_common_headfile.h"

char txt[30];   // LCD��Ļ��ʾ����

float yaw_last;         // ��¼��һʱ��ƫ����
float yaw_last_last;    // �洢ת��ǰ�ĽǶ�
float angle_taget;      // �����������Ƕ�
uint8 i;
uint8 text_pic_state=1;
float huandao_yaw_last=0;   // ����Բ��ƫ���Ǽ�¼

int main(void)
{
    clock_init(SYSTEM_CLOCK_600M);  // ����ɾ��
    debug_init();                   // ���Զ˿ڳ�ʼ��
    
    All_Init();
    
    wireless_uart_init();   // ����ת���ڳ�ʼ��
    
    MotorPID_Parameter_Init();      // PID������ʼ��
    
    while(1)
    {
  
//        Camera_Display();   // �����ѭ��

//        line_flag=0;
//        turn_flag=1;
//        angle_taget=30;
//        move_mode=2;
        
        ips200_displayimage03x((const uint8 *)mt9v03x_image_BandW, MT9V03X_W, MT9V03X_H);   // ��ֵ��ͼ����
        Draw_Line();     

        Pic_Text();         // Ŀ���⣬ѭ��ִ��
        if(text_pic_flag==1)
        {
            switch(text_pic_state)
            {
                case 1:
                {
                    yaw_last=Yaw;
                    
                    pit_disable(PIT_CH2);
//                    line_flag=0;
                    move_mode=2;
                    push_box_state=1;
                    text_pic_state = 2;
                }break;
                case 2:
                {
                    Push_Box(1);
                }break;
            }
        }
      
  
//        ips200_show_string(1,180,"TR:");
//        ips200_show_int(40, 180, turn_flag, 4); 
//        ips200_show_int(80, 180,  move_mode, 4); 
        
        ips200_show_string(1,260,"PS:");
        ips200_show_int(40, 260, push_box_state, 4); 

//        
//        ips200_show_int(40, 280, distance_x, 4); 
//        ips200_show_int(80, 280, distance_y, 4); 

        
//        ips200_show_string(1,260,"vx:");
//        ips200_show_int(40, 260, vx, 4); 
//        ips200_show_int(80, 260, vy, 4); 
//        ips200_show_int(120, 260, pic_pid_x.error_now, 4); 
//        ips200_show_int(160, 260, pic_pid_y.error_now, 4); 

        
        // ��������ֵ
        ips200_show_string(1,200,"EN:");
        ips200_show_int(40, 200, encoder_data[0], 4);        
        ips200_show_int(80, 200, encoder_data[1], 4);
        ips200_show_int(120, 200, encoder_data[2], 4);
        
        
        ips200_show_string(1,240,"Yaw:"); 
        ips200_show_int(40, 240, Yaw, 3);         // ƫ����
        ips200_show_int(80, 240, yaw_last, 3);    // ƫ����

//        // MCXĿ���⣬ͼƬ��������
//        ips200_show_string(0,300,"pic:");
//        ips200_show_int(50, 300,pic_text_x, 3);   
//		ips200_show_int(80, 300,pic_text_y, 3); 
//		ips200_show_int(110, 300,text_pic_flag, 3); 

//        ips200_show_int(10, 300,K_L,3);
//        ips200_show_int(40, 300,K_R,3);
//       
         ips200_show_int(80, 300,road_type.left_cirque,2);
         ips200_show_int(100, 300,huandao_stage,2);
//         ips200_show_int(120, 300,road_type.cross,2);
        ips200_show_string(1,220,"OFF:"); 
        ips200_show_int(40, 220, mid_offset, 3);         // ��������ƫ��
        
		
//        Wireless_Debug();
        
//        system_delay_ms(50);
//        printf("EN:%d,%d,%d\r\n",encoder_data[0],encoder_data[1],encoder_data[2]);
//		system_delay_ms(500);
	}
}

//------------------------------���Դ���------------------------------------
//        mid_offset
//        Wireless_Debug();
//        wireless_uart_send_string("TEXT\r\n");


//      Finall_Display();     // ����ʶ������ʾ
//		printf("----------------------------------------------------\r\n");
//		for(uint8_t temp=0; temp<MT9V03X_H; temp++)
//		{
//			printf("%d\r\n",right_line_list[temp]);
//		}
//		printf("----------------------------------------------------\r\n");

//		ips200_show_string(150,260,"hd:"); 
//		ips200_show_int(180, 260,road_type.right_cirque,2);
//		ips200_show_int(200, 260,huandao_stage,2);		
//        
//        ips200_show_string(150,280,"sz:"); 
//		ips200_show_int(180, 280,road_type.cross,2);
//        
//		ips200_show_string(1,300,"qu:"); 
//		ips200_show_int(30, 300,K_L, 3);   
//		ips200_show_int(60, 300,K_R, 3);   
//		
//		ips200_show_string(100,300,"ndiu/diu:"); 		
//		ips200_show_int(180, 300,budiuxian_hang, 3);   	// ������־λ
//		ips200_show_int(200, 300,diuxian_hang, 3);   	// ����״̬��

//        ips200_draw_line(0,0,239,0,RGB565_RED);
//        ips200_draw_line(0,30,239,30,RGB565_RED);
//        ips200_draw_line(0,60,239,60,RGB565_RED);
//        ips200_draw_line(0,90,239,90,RGB565_RED);
//        ips200_draw_line(0,120,239,120,RGB565_RED);
//        
//        ips200_draw_line(30,0,30,122,RGB565_RED);
//        ips200_draw_line(60,0,60,122,RGB565_RED);
//        ips200_draw_line(90,0,90,122,RGB565_RED);
//        ips200_draw_line(120,0,120,122,RGB565_RED);
//        ips200_draw_line(150,0,150,122,RGB565_RED);

