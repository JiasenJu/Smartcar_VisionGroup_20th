#include "debug.h"

uint32 buff_len_1;
uint32 buff_len_2;
uint32 buff_len_3;
uint32 buff_len_4;

char  text_buff_1[150] = {0};
char  text_buff_2[150] = {0};
char  text_buff_3[150] = {0};
char  text_buff_4[150] = {0};



// ���ߴ�������ʾ��������
void Wireless_Debug(void)
{
      
//    buff_len_1 = zf_sprintf((int8 *)text_buff_1,(int8 *)"%d,%d,%d,%d\n",encoder_data[0],encoder_data[1],(int)motor_pid0.expect,(int)motor_pid1.expect);
//    buff_len_1 = zf_sprintf((int8 *)text_buff_1,(int8 *)"%d,%d,%d\n",mid_offset,(int)huandao_yaw_last,(int)Yaw);
    
//      buff_len_1 = zf_sprintf((int8 *)text_buff_1,(int8 *)"%d,%d,%d,%d\n",
//            (int)encoder_data[0],(int)encoder_data[1],(int)motor_pid1.expect,(int)motor_pid2.expect);
    
//    buff_len_1 = zf_sprintf((int8 *)text_buff_1,(int8 *)"%d,%d,%d,%d,%d\n",huandao_stage,road_type.left_cirque,road_type.right_cirque,abs(right_line_list[MT9V03X_H-10]-right_line_list[MT9V03X_H-50]),abs(left_line_list[MT9V03X_H-10]-left_line_list[MT9V03X_H-50]));
//    buff_len_1 = zf_sprintf((int8 *)text_buff_1,(int8 *)"%d,%d,%d,%d\n",huandao_stage,road_type.left_cirque,road_type.right_cirque,road_type.cross);
//    buff_len_1 = zf_sprintf((int8 *)text_buff_1,(int8 *)"%d,%d\n",push_box_state,(int)huandao_yaw_last);
//    buff_len_1 = zf_sprintf((int8 *)text_buff_1,(int8 *)"%d,%d,%d,%d\n",pic_classify,pic_classify_flag,adject_finish_flag,text_pic_flag);
    buff_len_1 = zf_sprintf((int8 *)text_buff_1,(int8 *)"%d,%d,%d,%d,%d\n",huandao_stage,(int)mid_offset,road_type.cross,(int)angle_taget,(int)yaw_last);

    
//    buff_len_1 = zf_sprintf((int8 *)text_buff_1,(int8 *)"----------------------------------------------------\n");
      wireless_uart_send_buffer((uint8* )text_buff_1,buff_len_1);
//		for(uint8_t temp=0; temp<MT9V03X_H; temp++)
//		{
//            buff_len_1 = zf_sprintf((int8 *)text_buff_1,(int8 *)"%d,%d\n",left_line_list[temp],right_line_list[temp]);
//            wireless_uart_send_buffer((uint8* )text_buff_1,buff_len_1);
//            
//		}    
    
//    buff_len_1 = zf_sprintf((int8 *)text_buff_1,(int8 *)"%d\n",is_width_expanding());
    
//    buff_len_1 = zf_sprintf((int8 *)text_buff_1,(int8 *)"%d,%d\n",    ,err_y);
//    wireless_uart_send_buffer((uint8* )text_buff_1,buff_len_1);
    
    
//    buff_len_1 = zf_sprintf((int8 *)text_buff_1,(int8 *)"%d,%d\n",motor_pid0.expect,encoder_data[0]);
//    wireless_uart_send_buffer((uint8* )text_buff_1,buff_len_1);
}


// �������������ʾ����
uint8_t fin_flag=0;
void Finall_Display(void)
{
    if(road_type.zebra==1 || key[3].long_flag==1)
    {
        if(fin_flag==0)
        {
            ips200_clear();
            fin_flag=1;
        }
        
        // �����ַ���ʾ
        ips200_show_chinese(0, 0, 16, chinese_txt16[0], 2, RGB565_BLACK);
        ips200_show_chinese(40, 0, 16, chinese_txt17[0], 2, RGB565_BLACK);
        ips200_show_chinese(122, 0, 16, chinese_txt16[0], 2, RGB565_BLACK);
        ips200_show_chinese(160, 0, 16, chinese_txt17[0], 2, RGB565_BLACK);
        
        ips200_draw_line(0, 18, 239, 18, RGB565_BLACK);  
        ips200_draw_line(35, 0, 35, 319, RGB565_BLACK);  
        ips200_draw_line(120, 0, 120, 319, RGB565_BLACK);        
        ips200_draw_line(155, 0, 155, 319, RGB565_BLACK);

        
        // ��Ʒ������ʾ
        for(uint8_t temp=0; temp<pic_count; temp++)
        {
            if(temp<16)
            {
                ips200_show_uint(10, 20+temp*18, temp+1, 2);
                Item_Display(36, 20+temp*18, pic_recode[temp]);                     
            }
            else
            {
                ips200_show_uint(130, 20+(temp-16)*18, temp+1, 2);
                Item_Display(156, 20+(temp-16)*18, pic_recode[temp]);   
            }
   
        }
        
    }
}

//-------------------------------------------------------------------------------------------------------------------
// �������     ��¼��Ʒ�����ʾ
// ����˵��     x               ����x�������� ������Χ [0, ips200_x_max-1]
// ����˵��     y               ����y�������� ������Χ [0, ips200_y_max-1]
// ����˵��     item            ��Ʒ���  
//
// ��� ���� ��ʾ�� ͷ��ʽ���� ����  ��ӡ�� �ֻ� ���� ��˿�� �ֵ��� ǯ�� ���ñ� ʾ���� ������ ����
// 101  102  103   104        105   106    107 108  109    110   111  112    113    114    115
//-------------------------------------------------------------------------------------------------------------------
void Item_Display(uint16 x, uint16 y, uint8 item)
{
    if(item>100)
    {
        switch(item)
        {
            case 101: ips200_show_chinese(x, y, 16, chinese_txt1[0], 2, RGB565_BLACK);     break;   // ���
            case 102: ips200_show_chinese(x, y, 16, chinese_txt2[0], 2, RGB565_BLACK);     break;   // ����
            case 103: ips200_show_chinese(x, y, 16, chinese_txt3[0], 3, RGB565_BLACK);     break;   // ��ʾ��
            case 104: ips200_show_chinese(x, y, 16, chinese_txt4[0], 5, RGB565_BLACK);     break;   // ͷ��ʽ����
            case 105: ips200_show_chinese(x, y, 16, chinese_txt5[0], 2, RGB565_BLACK);     break;   // ����
            case 106: ips200_show_chinese(x, y, 16, chinese_txt6[0], 3, RGB565_BLACK);     break;   // ��ӡ��
            case 107: ips200_show_chinese(x, y, 16, chinese_txt7[0], 2, RGB565_BLACK);     break;   // �ֻ�
            case 108: ips200_show_chinese(x, y, 16, chinese_txt8[0], 2, RGB565_BLACK);     break;   // ����
            case 109: ips200_show_chinese(x, y, 16, chinese_txt9[0], 3, RGB565_BLACK);     break;   // ��˿��
            case 110: ips200_show_chinese(x, y, 16, chinese_txt10[0], 3, RGB565_BLACK);    break;   // �ֵ���
            case 111: ips200_show_chinese(x, y, 16, chinese_txt11[0], 2, RGB565_BLACK);    break;   // ǯ��
            case 112: ips200_show_chinese(x, y, 16, chinese_txt12[0], 3, RGB565_BLACK);    break;   // ���ñ�
            case 113: ips200_show_chinese(x, y, 16, chinese_txt13[0], 3, RGB565_BLACK);    break;   // ʾ����
            case 114: ips200_show_chinese(x, y, 16, chinese_txt14[0], 3, RGB565_BLACK);    break;   // ������
            case 115: ips200_show_chinese(x, y, 16, chinese_txt15[0], 2, RGB565_BLACK);    break;   // ����
            
            default:  ips200_show_chinese(x, y, 16, chinese_txt15[0], 2, RGB565_BLACK);    break;   // δʶ���
        }
    }
    else
    {
        ips200_show_uint(x, y, item, 2);
    }
}

// ��������һ��
void Buzzer_On(void)
{
    gpio_set_level(B15,1);
    system_delay_ms(80);
    gpio_set_level(B15,0);
}    


