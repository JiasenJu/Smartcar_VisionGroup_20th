#include "gyro.h"

imu963_data IMU_Offset;         //��ƫֵ
imu963_data IMU_Finished;       //�˲���ɵ�ֵ

int16 gyro_firstData_z=0;
float gyro_actualData_z=0;      //ʵ������

int16 gyro_firstData_accz=0;
float gyro_actualData_accz=0;      //ʵ������


float Yaw;//�����
uint8 IMU_Offset_Finished=0;    //��ƫ������ɱ�־λ
int32 acc_Vx=0,acc_Vy=0;        //���ٶȼƻ����ٶ�


//��ȡԭʼ����
void get_originalData()
{
	imu963ra_get_acc();//��ȡimu963���ٶȼ�����
	imu963ra_get_gyro();//��ȡimu963����������	
}


/* @function: ��ȡIMU��������ƫ��ԭʼ����
 * @param:none
 * @return:none
 * @notice: 
 */
void gyro_GetStateData(void)
{
	get_originalData();
	
	gyro_firstData_z=((gyro_originalData_z-IMU_Offset.gyro.z)/10)*10;
    gyro_firstData_accz=((acc_originalData_z-IMU_Offset.accdata.z)/10)*10;
    
//	gyro_firstData_z=gyro_originalData_z-IMU_Offset.gyro.z;
	
//	gyro_originalData_x-=IMU_Offset.gyro.x;
//	gyro_originalData_y-=IMU_Offset.gyro.y;
//	gyro_originalData_z-=IMU_Offset.gyro.z;
	
//	imu963ra_acc_x-=IMU_Offset.accdata.x;
//	imu963ra_acc_y-=IMU_Offset.accdata.y;
//	imu963ra_acc_z-=IMU_Offset.accdata.z;
}


/* @function: IMU�õ���ƫ
 * @param:none
 * @return:none
 * @notice: ��ƫ����Ҫ��������ֵ���ж�ʱ����ͬ����ƫ����Ӧ�÷��ڳ�ʼ����
 */
void gyro_offset()
{
	uint8 i=0;	
	IMU_Offset.gyro.x=IMU_Offset.gyro.y=IMU_Offset.gyro.z=0;
	IMU_Offset.accdata.x=IMU_Offset.accdata.y=IMU_Offset.accdata.z=0;
	
	IMU_Offset_Finished=0;
	for(i=0;i<100;i++)
	{
		get_originalData();
		
		IMU_Offset.gyro.x+=gyro_originalData_x;
		IMU_Offset.gyro.y+=gyro_originalData_y;
		IMU_Offset.gyro.z+=gyro_originalData_z;
		
		IMU_Offset.accdata.x+=acc_originalData_x;
		IMU_Offset.accdata.y+=acc_originalData_y;
		IMU_Offset.accdata.z+=acc_originalData_z;
		
		system_delay_ms(1);
	}
	
	IMU_Offset.gyro.x/=100;
	IMU_Offset.gyro.y/=100;
	IMU_Offset.gyro.z/=100;	
	IMU_Offset.accdata.x/=100;
	IMU_Offset.accdata.y/=100;
	IMU_Offset.accdata.z/=100;
	IMU_Offset.gyro.z/=100;	
	IMU_Offset_Finished=1;//��ƫ�������
}



/* @function: IMUһ�׻����˲�
 * @param:    gyro_data  �ñ���Ϊ��Ҫ�˲�������
 * @return:   gyro_data_finish �����˲�������
 * @notice:   none
 */
int16 FirstOrderFilter(int16 gyro_data)	
{
	float rate=0.4;
	int8 i;
	int16 gyro_data_sort[10]={0};
	int16 gyro_data_sum0=0,gyro_data_sum1=0;
	int16 gyro_data_finish=0;
	
	for(i=0;i<10;i++)
	{
		gyro_GetStateData();
		gyro_data_sort[i]=gyro_data;
	}
	for(i=0;i<5;i++)
	{
		gyro_data_sum0+=gyro_data_sort[i];
		if(i==4) gyro_data_sum0/=5;
	}
	for(i=5;i<10;i++)
	{
		gyro_data_sum1+=gyro_data_sort[i];
		if(i==9) gyro_data_sum1/=5;
	}
	
	gyro_data_finish=rate*gyro_data_sum1+(1.0-rate)*gyro_data_sum0;
	
	return gyro_data_finish;
}
//-------------------------------------------------------------------------------------------------------------------
//  @brief      ����ƽ���˲�
//  @param      SlideData   ����ָ�룬�������������ݵ�����
//  @param      object_data ����ָ�룬����������µ�����
//  @param      num 		�����˲������鳤��
//  @return     finish_data ��������˲�������
//  Sample usage:           
//-------------------------------------------------------------------------------------------------------------------
int16 SlideAverage_fliter(int16 *SlideData,int16 *object_data,int8 num)
{
	float data_sum=0;
	int16 finish_data=0;
	
	for(int8 i=num-1;i>0;i--)
	{
		SlideData[i]=SlideData[i-1];
	}
	SlideData[0]=*object_data;
	
	for(int8 i=0;i<num;i++)
	{
		data_sum+=SlideData[i];
	}
	
	finish_data=(int16)(data_sum/num);
	
	return finish_data;

}



//-------------------------------------------------------------------------------------------------------------------
//  @brief      gyro_30hz_parameter
//  @param      ������˹��ͨ�˲�������
//  @param      none
//  Sample usage:           
//-------------------------------------------------------------------------------------------------------------------
_Butterworth_parameter gyro_30hz_parameter =
{
  //200hz---30hz
  {1,  -0.7477891782585,    0.272214937925},
  {0.1311064399166,   0.2622128798333,   0.1311064399166}
};



//-------------------------------------------------------------------------------------------------------------------
//  @brief      ���װ�����˹�˲���ԭ��
//  @param      now_input   ��������
//  @param      buffer 			�м����ݻ���
//  @param      parameter 	�˲�����
//  @return     �˲�֮�������
//  Sample usage:           
//-------------------------------------------------------------------------------------------------------------------
float butterworth_lpf(float now_input,_Butterworth_data *buffer, _Butterworth_parameter *parameter)
{
    buffer->input_data[2] = now_input;

    /* Butterworth LPF */
    buffer->output_data[2] =   parameter->b[0] * buffer->input_data[2]
                             + parameter->b[1] * buffer->input_data[1]
                             + parameter->b[2] * buffer->input_data[0]
                             - parameter->a[1] * buffer->output_data[1]
                             - parameter->a[2] * buffer->output_data[0];
    /* x(n) ���� */
    buffer->input_data[0] = buffer->input_data[1];
    buffer->input_data[1] = buffer->input_data[2];
    /* y(n) ���� */
    buffer->output_data[0] = buffer->output_data[1];
    buffer->output_data[1] = buffer->output_data[2];

    return buffer->output_data[2];
}



//�����˲����ݴ������
int16 gyroFilterData_x[10]={0};
int16 gyroFilterData_y[10]={0};
int16 gyroFilterData_z[10]={0};

int16 accFilterData_x[10]={0};
int16 accFilterData_y[10]={0};
int16 accFilterData_z[10]={0};
uint8 acc_count_x=0,acc_count_y=0;


_Butterworth_data *butterworth_gyro_z=NULL;
//-------------------------------------------------------------------------------------------------------------------
//  @brief      IMU��ȡ�˲���ɵ�����
//  @param      none   	
//  @return     none
//  Sample usage:           
//-------------------------------------------------------------------------------------------------------------------
void gyro_FilterData()
{
	uint8 acc_dead_zone=5;
	
	gyro_GetStateData();
    IMU_Finished.gyro.z=SlideAverage_fliter(gyroFilterData_z,&gyro_firstData_z,5);
	gyro_actualData_z=imu963ra_gyro_transition(IMU_Finished.gyro.z);    
    
	IMU_Finished.accdata.z=SlideAverage_fliter(accFilterData_z,&gyro_firstData_accz,5);
    gyro_actualData_accz=imu963ra_acc_transition(IMU_Finished.accdata.z);
    
    
//	IMU_Finished.gyro.x=SlideAverage_fliter(gyroFilterData_x,&gyro_originalData_x,10);
//	IMU_Finished.gyro.y=SlideAverage_fliter(gyroFilterData_y,&gyro_originalData_y,10);
//	IMU_Finished.gyro.z=SlideAverage_fliter(gyroFilterData_z,&gyro_originalData_z,10);
	

//	IMU_Finished.gyro.z=butterworth_lpf(gyro_originalData_z,butterworth_gyro_z,&gyro_30hz_parameter);
		
}


//-------------------------------------------------------------------------------------------------------------------
//  @brief      �����ǻ��ֵõ������
//  @param      none
//  @param           	
//  @return     none
//  Sample usage:           
//-------------------------------------------------------------------------------------------------------------------
void get_angle()
{
	int16 Gyro_DeadZone=3;//����������
	float Gyro_Rate = 0.01f;
	
	Yaw+=gyro_actualData_z*Gyro_Rate;
    
//    Yaw=(Yaw>-360) ? Yaw : Yaw+360;
//    Yaw=(Yaw<360) ? Yaw : Yaw-360;
        
//	if(IMU_Finished.gyro.z>Gyro_DeadZone||IMU_Finished.gyro.z<-Gyro_DeadZone)
//	{
//	Yaw+=(int16)IMU_Finished.gyro.z*Gyro_Rate;
//	}
}	
