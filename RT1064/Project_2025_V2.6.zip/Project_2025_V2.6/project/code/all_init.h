#ifndef __ALL_INIT_H
#define __ALL_INIT_H
#include "zf_common_headfile.h"

void All_Init(void);


#endif

