#include "mcx_detect.h"


// 确认检测到图片Y轴的坐标
#define PIC_TEXT_EXP_Y 25

/*  MCX返回图片坐标示意： 
   0 —————>x  240
240 |
    |
    |
0   |
   y 
*/

// 目标检测openart数据定义
uint8 uart_get_data_2[64];          // openart_mini 1号摄像头UART1串口接收数据缓冲区
uint8 fifo_get_data_2[64];          // fifo 输出读出缓冲区
uint8 get_data_2 = 0;               // 接收数据变量
uint32 fifo_data_count_2 = 0;       // fifo数据个数
fifo_struct uart_data_fifo_2;       // FIFO结构体
uint8* uart_data_2=NULL;            // 串口数据转存地址，在此基础上进行运动控制


/**********  目标检测   *************/
uint8 text_uart_flag = 0;           // 串口接收到数据标志位，接收到数据置1
uint8 text_pic_flag = 0;            // 目标检测标志位，检测到图片置1
uint8 pic_rx_flag = 0;          
uint8 pic_adjust_flag = 0;          // 位置调整标志位
uint16 pic_text_x=0,pic_text_y=0;   // 目标检测图片中心点,接收到的数据，未滤波
uint16 pic_x=0,     pic_y=0;        //滤波后的数据

uint16 pic_x_last=0;

uint8_t text_pic_enable=1;          // 判断是否进行目标检测判定 1：开启 0：关闭
uint32 Pic_Num=0;//中断执行次数

typedef struct      // MCX目标检测
{
    uint16 res_x1;
    uint16 res_y1;
    uint16 res_x2;
    uint16 res_y2;
}od_result_t;   

volatile od_result_t od_result[10];
uint16_t pic_area;      // 图像面积

// openart串口初始化， UART4, 用作目标检测
void MCX_Uart_Init(void)       
{
    fifo_init(&uart_data_fifo_2, FIFO_DATA_8BIT, uart_get_data_2, 64);      // 初始化 fifo 挂载缓冲区
    uart_init(UART_4, 115200, UART4_TX_C16, UART4_RX_C17);                  // 串口初始化
    uart_rx_interrupt(UART_4, ZF_ENABLE);                                   // 开启 UART_INDEX 的接收中断
    interrupt_set_priority(LPUART4_IRQn, 0);                                // 设置对应 UART_INDEX 的中断优先级为 0
}


// MCX目标监测，串口中断接收返回的图片坐标数据
void uart_MCX_interrupt_handler(void)
{ 
    uint8 get_data_2 = 0;        // 接收数据变量
    uint32 temp_length = 0;
    uint8 od_num = 0;
    
    if(uart_query_byte(UART_4, &get_data_2))
    {
        fifo_write_buffer(&uart_data_fifo_2, &get_data_2, 1);   
    }
    
    if(0xFF == get_data_2)      // 读取第1个数据，用于判断帧头，使用完清除此数据
    {
        text_uart_flag = 1;
        
        temp_length = 1;
        fifo_read_buffer(&uart_data_fifo_2, fifo_get_data_2, &temp_length, FIFO_READ_AND_CLEAN);
        if(0xAA == fifo_get_data_2[0])
        {
            temp_length = 1;    // 读取第1个数据，用于获取目标序号，使用完清除此数据
            fifo_read_buffer(&uart_data_fifo_2, fifo_get_data_2, &temp_length, FIFO_READ_AND_CLEAN);
            od_num = fifo_get_data_2[0];
           
            temp_length = 8;    // 读取8个数据，用于获取目标数据，然后转移到结构体数组中
            fifo_read_buffer(&uart_data_fifo_2, fifo_get_data_2, &temp_length, FIFO_READ_AND_CLEAN);
            memcpy((uint8*)(&od_result[od_num]), fifo_get_data_2, 8);
        
            pic_text_x = (od_result[0].res_x1+od_result[0].res_x2)/2;
            pic_text_y = (od_result[0].res_y1+od_result[0].res_y2)/2;
           
            pic_area = (od_result[0].res_x2-od_result[0].res_x1)*(od_result[0].res_y2-od_result[0].res_y1);
            
        }
        fifo_clear(&uart_data_fifo_2);
    }
}

int16_t err_y,err_x;
/****************************************************************
 *  @brief    图片检测，在接收到数据后，判断图片的位置
 *  @param    void
 *  @return   void
 *  Sample usage
*****************************************************************/
void Pic_Text(void)
{     
    if(text_pic_enable==1)
    {
        if(text_uart_flag==1)
        {
            pic_x= pic_text_x*0.3+pic_x_last*0.7;
            pic_y= pic_text_y;
            
            pic_x_last=pic_x;   // 记录上次图片X坐标
            
            err_y = PIC_EXP_Y-pic_y;//偏差的值
           
            // 进入预定距离提前减速
            if(pic_area > 500)
            {
//                if(err_y<PIC_TEXT_EXP_Y+60)          motor_speed_base = SPEED_BASE-70; 
//                else if(err_y<PIC_TEXT_EXP_Y+50)     motor_speed_base = SPEED_BASE-90;     
//                else if(err_y<PIC_TEXT_EXP_Y+40)     motor_speed_base = SPEED_BASE-125;     
                
                if(err_y<PIC_TEXT_EXP_Y+45)          motor_speed_base = 195; 
                else if(err_y<PIC_TEXT_EXP_Y+25)     motor_speed_base = 165;   
            }

            if(err_y<PIC_TEXT_EXP_Y && pic_area>1800)
            {
                text_pic_flag = 1;  // 图片达到预定距离
            }
            text_uart_flag=0;
        }
    }
}

