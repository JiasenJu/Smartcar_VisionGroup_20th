#ifndef __OPENART_MINI_H_
#define __OPENART_MINI_H_

#include "zf_common_headfile.h"

// Ŀ��ʶ��
extern uint8 uart_get_data_1[64];      
extern uint8 fifo_get_data_1[64];      
extern uint8 get_data_1;           
extern uint32 fifo_data_count_1;   
extern fifo_struct uart_data_fifo_1;
extern uint8* uart_data_1;

  
extern int8 pic_classify;    
extern uint8 pic_classify_flag;
extern uint8 pic_errow;
      
void openart_mini_1_Init(void);


#endif

    