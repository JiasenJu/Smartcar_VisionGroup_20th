#ifndef __ENCODER_H
#define __ENCODER_H

#include "zf_common_headfile.h"

#define ENCODER_LH                       (QTIMER1_ENCODER2)
#define ENCODER_LH_LSB                   (QTIMER1_ENCODER2_CH1_C2)
#define ENCODER_LH_DIR                   (QTIMER1_ENCODER2_CH2_C24)

#define ENCODER_RH                       (QTIMER2_ENCODER1)
#define ENCODER_RH_LSB                   (QTIMER2_ENCODER1_CH1_C3)
#define ENCODER_RH_DIR                   (QTIMER2_ENCODER1_CH2_C25)
                                        
#define ENCODER_MB                       (QTIMER1_ENCODER1)
#define ENCODER_MB_LSB                   (QTIMER1_ENCODER1_CH1_C0)
#define ENCODER_MB_DIR                   (QTIMER1_ENCODER1_CH2_C1)
                                                 

extern int16    encoder_data_orginal[3];    // ������ԭʼ����
extern int16    encoder_data[3];            // �������˲��������


void Encoder_Init(void);
void Encoder_Get(void);
    


#endif

