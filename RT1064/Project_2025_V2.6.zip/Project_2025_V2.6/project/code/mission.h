#ifndef __MISSION_H
#define __MISSION_H
#include "zf_common_headfile.h"


// ����ͼƬ��������
#define expect_pic_x 155
#define expect_pic_y 145 


extern uint8_t pic_recode[];
extern uint8_t pic_count;

extern uint8 adject_finish_flag;
extern uint8 push_box_state;

extern uint8 xj_state;

extern uint16_t trace_count;
extern uint8_t trace_cnt_flag;

extern uint8_t mission_flag;


void Position_Adjust(void);
void Position_Adjust2(void);

void Trace_Goback(void);

void Push_Box(void);
//void Push_Box(uint8 mode);

int16 my_abs(int16 data);

#endif

