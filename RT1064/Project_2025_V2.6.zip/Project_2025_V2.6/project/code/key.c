#include "key.h"


struct keys key[4] = {0};     


// TIM 10ms
void Key_work(void)     
{
    key[0].key_state = gpio_get_level(D15);     
    key[1].key_state = gpio_get_level(D14);
    key[2].key_state = gpio_get_level(D13);
    key[3].key_state = gpio_get_level(D12);
    
    for(int i=0;i<4;i++)
	{
		switch(key[i].judge_state)     
		{
			case 0:
			{
				if(key[i].key_state==0) 
				{
					key[i].judge_state=1;
					key[i].key_time=0;
				}
			}break;
			case 1:
			{
				if(key[i].key_state==0)
				{
					key[i].judge_state=2;
				}
				else key[i].judge_state=0;
			}break;
			case 2:
			{
                if(key[i].key_state==1)    
                {
					key[i].judge_state=0;

					if(key[i].key_time<99)  key[i].key_flag=1;            
                }
                else
                {
                    key[i].key_time++;
							
                    if(key[i].key_time>99)  key[i].long_flag=1;
                }
			}break;
		}
	}
}
