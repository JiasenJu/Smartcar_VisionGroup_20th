#ifndef _MCX_DETECT_H_
#define _MCX_DETECT_H_

#include "zf_common_headfile.h"

// MCXʶ��ͼƬ��������
#define PIC_EXP_X   155
#define PIC_EXP_Y   150

// ȷ�ϼ�⵽ͼƬY�������
#define PIC_TEXT_EXP_Y 25

// Ŀ����
extern uint8 uart_get_data_2[64];      
extern uint8 fifo_get_data_2[64];      
extern uint8 get_data_2;           
extern uint32 fifo_data_count_2;   
extern fifo_struct uart_data_fifo_2;


extern uint8 text_uart_flag;
extern uint8 text_pic_flag;
extern uint8 pic_rx_flag;  

extern uint8 pic_adjust_flag;
extern uint16 pic_text_x,pic_text_y; 
extern uint16 pic_x,     pic_y;      
extern uint32 Pic_Num;

extern uint8_t text_pic_enable;


extern uint16_t pic_area;
extern int16_t err_y,err_x;



void MCX_Uart_Init(void);
void Pic_Text(void);


#endif 
