#include "pid.h"

#define OUTPUT_MAX 4500

/****************************************************************
 *  @brief    增量式PI速度环，用作串级PID内环
 *  @param    pid_parameter motor_pid
 *  @return   void
 *  Sample usage
*****************************************************************/
void Incremental_PID(struct pid_parameter *pid,int16 speed_now)
{
	pid->error_last_last=pid->error_last;
	pid->error_last=pid->error_now;
	
	pid->error_now=pid->expect-speed_now;
	
	pid->output+=pid->kp*(pid->error_now-pid->error_last)
				+pid->ki*pid->error_now
				+pid->kd*(pid->error_now-2*pid->error_last+pid->error_last_last);
	
	if(pid->output>OUTPUT_MAX) pid->output=OUTPUT_MAX;
	if(pid->output<-OUTPUT_MAX) pid->output=-OUTPUT_MAX;
}


/****************************************************************
 *  @brief    位置式PD位置环，用作常规循线
 *  @param    中线偏差
 *  @return   void
 *  Sample usage
*****************************************************************/
void Direction_PD(struct pid_parameter *pid, float mid_error)
{
    int16 pid_output;   // PD输出PWM
    int16 peak=100;     // 积分限幅      
    
    pid->error_now = mid_error;
    pid->output = pid->kp * pid->error_now
                + pid->ki*pid->error_integral
                + pid->kd * (pid->error_now - pid->error_last);
    
    pid->error_last = pid -> error_now;
	pid->error_integral+=pid->error_now;   
    
    pid->error_integral = (pid->error_integral<peak) ? peak : pid->error_integral;
    pid->error_integral = (pid->error_integral>peak) ? peak: pid->error_integral;  
    
    if(pid->output>OUTPUT_MAX) pid->output=OUTPUT_MAX;
	if(pid->output<-OUTPUT_MAX) pid->output=-OUTPUT_MAX;
}

//-------------------------------------------------------------------------------------------------------------------
//  @brief      位置式PD 角速度环 
//  @param      pid_parameter *pid PID参数
//  @param           	
//  @return     
//  Sample usage:           
//-------------------------------------------------------------------------------------------------------------------
void Positional_Vel_PD(struct pid_parameter *pid)
{
	uint8 error_deadzone=1.0f;
	uint16 range=25;
	
	if(pid->error_now<error_deadzone&&pid->error_now>-error_deadzone) pid->error_now=0;
	
	
	
	pid->output=pid->kp*pid->error_now/100.0f
			   +pid->kd*(pid->error_now-pid->error_last);
	
	pid->error_last=pid->error_now;
	//输出限幅
	if(pid->output>range) pid->output=range;
	if(pid->output<-range) pid->output=-range;

}
//-------------------------------------------------------------------------------------------------------------------
//  @brief     位置式PID 角度环 
//  @param     pid_parameter *pid 	PID参数
//  @param     angle                陀螺仪计算角度      	
//  @return     none
//  Sample usage:           
//-------------------------------------------------------------------------------------------------------------------
void Position_PID(struct pid_parameter *pid,float angle)
{
	float error_deadzone=0.1;//设置死区
	uint16_t output_limit=200;
    
	pid->expect=angle;
	pid->error_last=pid->error_now;
	pid->error_now=Yaw-(float)pid->expect;
	
	if(pid->error_now<error_deadzone&&pid->error_now>-error_deadzone) pid->error_now=0; 
	
	pid->error_integral+=pid->error_now;
	
	pid->output=(float)pid->kp*pid->error_now/10.0f
				+(float)pid->ki*pid->error_integral
				+(float)pid->kd*(pid->error_now-pid->error_last)/10.0f;
                
                
    if(pid->output>output_limit) pid->output=output_limit;
	if(pid->output<-output_limit) pid->output=-output_limit;            
}


/****************************************************************
 *  @brief    图片中心坐标调整
 *  @param    
 *  @return     
 *  Sample usage
*****************************************************************/
void Position_XY_PID(struct pid_parameter *pid)
{
	uint16 range=200;           // 输出限幅
    int16 peak=600;             // 积分限幅
    
	pid->error_integral+=pid->error_now;
	
	pid->output=(float)pid->kp*pid->error_now/10.0f
				+(float)pid->ki*pid->error_integral
				+(float)pid->kd*(pid->error_now-pid->error_last)/10.0f;
				
	pid->error_last=pid->error_now;
                
    pid->error_integral = (pid->error_integral<peak) ? peak : pid->error_integral;
    pid->error_integral = (pid->error_integral>peak) ? peak: pid->error_integral;
                
	//输出限幅
	if(pid->output>range) pid->output=range;
	if(pid->output<-range) pid->output=-range;
}
