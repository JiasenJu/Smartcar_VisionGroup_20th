#ifndef __KEY_H
#define __KEY_H

#include "zf_common_headfile.h"


struct keys
{
   uint8_t judge_state;    
   bool key_state;         
   bool key_flag;          
   bool long_flag;         
   uint8_t key_time;
};
  
extern struct keys key[4];

void Key_work(void);     

#endif
