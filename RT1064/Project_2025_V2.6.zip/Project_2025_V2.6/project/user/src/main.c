#include "zf_common_headfile.h"

#define DEBUGE_LCD  1

char txt[30];           // LCD��Ļ��ʾ����

float yaw_last;         // ��¼��һʱ��ƫ����
float yaw_last_last;    // �洢ת��ǰ�ĽǶ�
float angle_taget;      // �����������Ƕ�

uint8 text_pic_state=1;
float huandao_yaw_last=0;   // ����Բ��ƫ���Ǽ�¼
float cross_yaw_last=0;     // ����Բ��ƫ���Ǽ�¼

int main(void)
{
    clock_init(SYSTEM_CLOCK_600M);  // ����ɾ��
//    debug_init();                   // ���Զ˿ڳ�ʼ��
    
    All_Init();
    MotorPID_Parameter_Init();      // PID������ʼ��    
    
    wireless_uart_init();   // ����ת���ڳ�ʼ��
    
    ips200_show_string(0,0,"Wait:");
    // �ȴ�����
    while(1)
    {
        ips200_show_int(50, 0, key[0].key_time, 4);    
        if(key[0].key_flag==1)
        {
            key[0].key_flag=0;
            
            stop_flag=0;
            ips200_show_string(0,0,"Ready:");
            move_mode=2;
            system_delay_ms(500);
            Motor_Move(0,250,800);
            
            move_mode=1;
            pit_ms_init(PIT_CH2, 20);               // �����
            break;            
        }
        
        stop_flag=1;

    }
    
    // ����
    while(1)
    {
        if(key[3].long_flag==1) // ǿ��ͣ��
        {
            road_type.zebra=1;
            
            pit_disable(PIT_CH0);
            pit_disable(PIT_CH2);
    
            line_flag=0;
            stop_flag=1; 
            Motor_SpeedText(0,0,0);
            Finall_Display();           // ʶ��ͼƬ������ʾ
        }

        if(text_pic_flag==1)
        {
            move_mode=2;//�˶��ֽ�ģʽ
            switch(text_pic_state)//��⵽Ŀ�������־λ
            {
                case 1:
                {
                    move_mode=2;    //�˶��ֽ�ģʽ
                    yaw_last=Yaw;   //��¼�Ƕ�
                    road_type.bend=Cirque_Direction();
                    push_box_state=1;
                    text_pic_state = 2;
                }break;
                case 2:
                {

                        turn_flag=1;
                        z_turn_flag =2;                        
                        text_pic_state = 3;

                }break;
                case 3:
                {
                    Push_Box();
                }break;
            }
        }
        
        Finall_Display();           // ʶ��ͼƬ������ʾ

        Wireless_Debug();           // ���ߴ���


        if(road_type.zebra!=1)
        {
            /*------------------------------ ��ʾ���� ------------------------------------*/
//            ips200_displayimage03x((const uint8 *)mt9v03x_image_BandW, MT9V03X_W, MT9V03X_H);    // ��ֵ��ͼ����ʾ
//            ips200_displayimage03x((const uint8 *)mt9v03x_image, MT9V03X_W, MT9V03X_H);          // �Ҷ�ͼ����ʾ
//            Draw_Line();   


            ips200_show_string(0,160,"PS:");
            ips200_show_int(50, 160, push_box_state, 4);    
            ips200_show_int(100, 160, mid_offset, 4);  
            
            // MCXĿ���⣬ͼƬ��������
            ips200_show_string(0,300,"pic:");
            ips200_show_int(50, 300,pic_x, 3);   
            ips200_show_int(80, 300,pic_y, 3);            

            ips200_show_string(1,240,"Yaw:"); 
            ips200_show_int(40, 240, Yaw, 3);         // ƫ����
            ips200_show_int(80, 240, yaw_last, 3);    // ƫ����
            
//            ips200_show_string(1,260,"bend:");
//            ips200_show_int(50, 260,road_type.bend,2);
            
//            ips200_show_int(1, 140, huandao_stage, 4);    
//            ips200_show_int(50, 140, Threshold, 4);    

//            
//            ips200_show_string(150,180,"TR:");
//            ips200_show_int(200, 180, turn_flag, 4); 
            
//            Find_Longest_White_Column(&longest_white_length, &longest_white_column);

//            ips200_show_int(1, 180, longest_white_length,3); 
//            ips200_show_int(40, 180, longest_white_column, 3); 


            
            // ��������ֵ
//            ips200_show_string(1,200,"EN:");
//            ips200_show_int(40, 200, encoder_data[0], 4);        
//            ips200_show_int(80, 200, encoder_data[1], 4);
//            ips200_show_int(120, 200, encoder_data[2], 4);
//    
            
//            ips200_show_int(180, 220,cross_left[0], 3);
//            ips200_show_int(140, 220, cross_right[0],3);
        
//            ips200_show_int(120, 240, gyro_actualData_z, 4); 
//            ips200_show_int(160, 240, gyro_actualData_accz, 4); 
            
//            ips200_show_string(60,280,"sz:"); 
//            ips200_show_int(120, 280,road_type.cross,2);
//            ips200_show_int(150, 280,road_type.right_cirque,2);
//            ips200_show_int(180, 280,road_type.left_cirque,2);
        }

	}
}

//------------------------------���Դ���------------------------------------
//        mid_offset
//        Wireless_Debug();
//        wireless_uart_send_string("TEXT\r\n");


//      Finall_Display();     // ����ʶ������ʾ
//		printf("----------------------------------------------------\r\n");
//		for(uint8_t temp=0; temp<MT9V03X_H; temp++)
//		{
//			printf("%d\r\n",right_line_list[temp]);
//		}
//		printf("----------------------------------------------------\r\n");

//		ips200_show_string(150,260,"hd:"); 
//		ips200_show_int(180, 260,road_type.right_cirque,2);
//		ips200_show_int(200, 260,huandao_stage,2);		
//        
//        ips200_show_string(150,280,"sz:"); 
//		ips200_show_int(180, 280,road_type.cross,2);
//        
//		ips200_show_string(1,300,"qu:"); 
//		ips200_show_int(30, 300,K_L, 3);   
//		ips200_show_int(60, 300,K_R, 3);   
//		
//		ips200_show_string(100,300,"ndiu/diu:"); 		
//		ips200_show_int(180, 300,budiuxian_hang, 3);   	// ������־λ
//		ips200_show_int(200, 300,diuxian_hang, 3);   	// ����״̬��



//        ips200_show_int(10, 300,K_L,3);
//        ips200_show_int(40, 300,K_R,3);
//       
//         ips200_show_int(80, 300,road_type.left_cirque,2);
//         ips200_show_int(100, 300,huandao_stage,2);
//         ips200_show_int(120, 300,road_type.cross,2);

//        Camera_Display();   // �����ѭ��
//        ips200_draw_line(0,0,239,0,RGB565_RED);
//        ips200_draw_line(0,30,239,30,RGB565_RED);
//        ips200_draw_line(0,60,239,60,RGB565_RED);
//        ips200_draw_line(0,90,239,90,RGB565_RED);
//        ips200_draw_line(0,120,239,120,RGB565_RED);
//        
//        ips200_draw_line(30,0,30,122,RGB565_RED);
//        ips200_draw_line(60,0,60,122,RGB565_RED);
//        ips200_draw_line(90,0,90,122,RGB565_RED);
//        ips200_draw_line(120,0,120,122,RGB565_RED);
//        ips200_draw_line(150,0,150,122,RGB565_RED);

//		ips200_show_string(1,300,"qu:"); 
//		ips200_show_int(30, 300,K_L, 3);   
//		ips200_show_int(60, 300,K_R, 3); 

//        ips200_show_string(1,260,"vx:");
//        ips200_show_int(40, 260, vx, 4); 
//        ips200_show_int(80, 260, vy, 4); 
//        ips200_show_int(120, 260, pic_pid_x.error_now, 4); 
//        ips200_show_int(160, 260, pic_pid_y.error_now, 4); 

//            ips200_show_string(0,140,"class:"); 
//            ips200_show_int(50, 140, pic_classify, 3);        
//            ips200_show_int(1, 140, pic_area, 5);           
//            

